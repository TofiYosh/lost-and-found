<?php
  include "h_f/header.php";

  if(isset($_SESSION["email"])){
    header("location: index.php");
    exit;
  }

  $email = "";
  $error = "";
  if($_SERVER["REQUEST_METHOD"] == 'POST'){
    $email = $_POST['email'];
    $pass = $_POST['pass'];

    if(empty($email) || empty($pass)){
      $error = "Email and Password are required!";
    }
    else {
      include "dbtools/db.php";
      $conn = conn();
      $statement = $conn->prepare("SELECT user_id, fname, lname, phone, pass FROM users WHERE email=?");

      $statement->bind_param('s', $email);
      $statement->execute();
      $statement->bind_result($user_id, $fname, $lname, $phone, $stored_password);

      if ($statement->fetch()){
        if ($pass === $stored_password){
          $_SESSION["user_id"] = $user_id;
          $_SESSION["fname"] = $fname;
          $_SESSION["lname"] = $lname;
          $_SESSION["email"] = $email;
          $_SESSION["phone"] = $phone;

          header("location: index.php");
          exit;
        }
      }

      $statement->close();
      $error = "Email or Password invalid";

    }
  }
?>



<div class="container py-5">
  <div class="mx-auto border shadow p-4" style="width: 400px">
    <h2 class="text-center mb-4">Log-in</h2>
    <hr>

    <?php if (!empty($error)) {?>
      <div class="alert alert-danger alert dismissible fade show" role="alert">
        <strong><?= $error?></strong>
      </div>
    <?php }?>

    <form method="post">
      <div class="mb-3">
        <label class="form-label">Email</label>
        <input class="form-control" name="email" value="<?= $email?>">
      </div>

      <div class="mb-3">
        <label class="form-label">Password</label>
        <input class="form-control" type="password" name="pass">
      </div>

      <div class="row mb-3">
        <div class="col d-grid">
          <button type="submit" class="btn btn-primary">Log-in</button>
        </div>
        <div class="col d-grid">
          <a href="index.php" class="btn btn-outline-primary">Cancel</a>
        </div>
      </div>
    </form>
  </div>
</div>

<?php
 include "h_f/footer.php";
?>