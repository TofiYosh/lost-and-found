<?php
  include "h_f/header.php";

  if(isset($_SESSION["email"])){
    header("location: index.php");
    exit;
  }

  $fname = "";
  $lname = "";
  $email = "";
  $phone = "";

  $fname_error = "";
  $lname_error = "";
  $email_error = "";
  $phone_error = "";
  $pass_error = "";
  $c_pass_error = "";

  $error = false;

  if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $pass = $_POST['pass'];
    $c_pass = $_POST['c_pass'];

    //Validation
    if(empty($fname)){
      $fname_error = "First Name is required";
      $error = true;
    }

    if(empty($lname)){
      $lname_error = "Last Name is required";
      $error = true;
    }

    if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
      $email_error = "Email format is not valid";
      $error = true;
    }
    include "dbtools/db.php";
    $dbconn = conn();
    $statement = $dbconn->prepare("SELECT user_id FROM users WHERE email=?");
    $statement->bind_param("s", $email);
    $statement->execute();
    $statement->store_result();
    if($statement->num_rows > 0){
      $email_error = "Email is already used";
      $error = true;
    }
    $statement->close();

    if(!preg_match("/^(\+|00\d{1,3})?[- ]?\d{7,12}$/", $phone)){
      $phone_error = "Phone format is not valid";
      $error = true;
    }

    if(strlen($pass) < 6){
      $pass_error = "Password must have atlease 6 characters";
      $error = true;
    }

    if($c_pass != $pass){
      $c_password_error = "Password and Confirm Password do not match";
      $error = true;
    }

    if(!$error){
      $statement = $dbconn->prepare(
        "INSERT INTO users (fname, lname, email, phone, pass)" . 
        "VALUES (?, ?, ?, ?, ?)"
      );

      $statement->bind_param('sssss', $fname, $lname, $email, $phone, $pass);
      $statement->execute();
      $insert_id = $statement->insert_id;
      $statement->close();

      $_SESSION["user_id"] = $insert_id;
      $_SESSION["fname"] = $fname;
      $_SESSION["lname"] = $lname;
      $_SESSION["email"] = $email;
      $_SESSION["phone"] = $phone;

      header("location: index.php");
      exit;

    }
  }
?>

<div class="container py-5">
  <div class="row">
    <div class="col-lg-6 mx-auto border shadow p-4">
      <h2 class="text-center mb-4">Register</h2>
      <hr>

      <form method="post">
        <div class="row mb-3">
          <label class="col-sm-4 col-form-label">First Name</label>
          <div class="col-sm-8">
            <input class="form-control" name="fname" value="<?= $fname?>">
            <span class="text-danger"><?= $fname_error?></span>
          </div>
        </div>

        <div class="row mb-3">
          <label class="col-sm-4 col-form-label">Last Name</label>
          <div class="col-sm-8">
            <input class="form-control" name="lname" value="<?= $lname?>">
            <span class="text-danger"><?= $lname_error?></span>
          </div>
        </div>

        <div class="row mb-3">
          <label class="col-sm-4 col-form-label">Email</label>
          <div class="col-sm-8">
            <input class="form-control" name="email" value="<?= $email?>">
            <span class="text-danger"><?= $email_error?></span>
          </div>
        </div>

        <div class="row mb-3">
          <label class="col-sm-4 col-form-label">Phone</label>
          <div class="col-sm-8">
            <input class="form-control" name="phone" value="<?= $phone?>">
            <span class="text-danger"><?= $phone_error?></span>
          </div>
        </div>

        <div class="row mb-3">
          <label class="col-sm-4 col-form-label">Password</label>
          <div class="col-sm-8">
            <input class="form-control" type="password" name="pass">
            <span class="text-danger"><?= $pass_error?></span>
          </div>
        </div>

        <div class="row mb-3">
          <label class="col-sm-4 col-form-label">Confirm Password</label>
          <div class="col-sm-8">
            <input class="form-control" type="password" name="c_pass">
            <span class="text-danger"><?= $c_pass_error?></span>
          </div>
        </div>

        <div class="row mb-3">
          <div class="offset-sm-4 col-sm-4 d-grid">
            <button type="submit" class="btn btn-primary">Register</button>
          </div>
          <div class="col-sm-4 d-grid">
            <a href="index.php" class="btn btn-outline-primary">
              Cancel
            </a>
          </div>
        </div>
        .
      </form>

    </div>
  </div>
</div>

<?php
include "h_f/footer.php"
?>

    