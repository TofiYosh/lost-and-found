<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "lnf_test";

$connection = new mysqli($servername, $username, $password, $database);

$name = "";
$email = "";
$phone = "";
$address = "";

$errorMessage = "";
$successMessage = "";

if($_SERVER['REQUEST_METHOD'] == 'POST'){
  $name = $_POST["name"];
  $email = $_POST["email"];
  $phone = $_POST["phone"];
  $address = $_POST["address"];

  do {
    if (empty($name) || empty($email) || empty($phone) || empty($address)) {
      $errorMessage = "All the fields are required";
      break;
    }
    
    try {
      // First check if email already exists
      $check = $connection->prepare("SELECT email FROM clients WHERE email = ?");
      $check->bind_param("s", $email);
      $check->execute();
      $check->store_result();
      
      if ($check->num_rows > 0) {
          $errorMessage = "Email address already exists";
          $check->close();
          break;
      }
      $check->close();
      
      // Insert with prepared statement
      $stmt = $connection->prepare("INSERT INTO clients (name, email, phone, address) VALUES (?, ?, ?, ?)");
      $stmt->bind_param("ssss", $name, $email, $phone, $address);
      $result = $stmt->execute();
      
      if(!$result){
          $errorMessage = "Database error: " . $stmt->error;
          break;
      }
      
      // Only redirect on success
      $successMessage = "Client added correctly";
      header("location: index_2.php");
      exit;
      
    } catch (mysqli_sql_exception $e) {
        if (str_contains($e->getMessage(), 'Duplicate entry')) {
            $errorMessage = "Email address already exists";
        } else {
            $errorMessage = "Database error: " . $e->getMessage();
        }
    }

  } while (false);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MSU-GENSAN: Lost and Found System (create)</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css">
  <script src="	https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js
"></script>

</head>
<body>
  <div class="container my-5">
    <h2>New Client</h2>

    <?php
    if (!empty($errorMessage)) {
      echo "
      <div class='alert alert-warning alert-dismissible fade show' role='alert'>
        <strong>$errorMessage</strong>
        <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
      </div>
      ";
    }
    ?>

    <form method="post">
      <div class="row mb-3">
        <label class="col-sm-3 col-form-label">Name</label>
        <div class="col-sm-6">
          <input type="text" class="form-control" name="name" value="<?=$name; ?>">
        </div>
      </div>
      <div class="row mb-3">
        <label class="col-sm-3 col-form-label">Email</label>
        <div class="col-sm-6">
          <input type="text" class="form-control" name="email" value="<?=$email; ?>">
        </div>
      </div>
      <div class="row mb-3">
        <label class="col-sm-3 col-form-label">Phone</label>
        <div class="col-sm-6">
          <input type="text" class="form-control" name="phone" value="<?=$phone; ?>">
        </div>
      </div>
      <div class="row mb-3">
        <label class="col-sm-3 col-form-label">Address</label>
        <div class="col-sm-6">
          <input type="text" class="form-control" name="address" value="<?=$address; ?>">
        </div>
      </div>

      <?php
      if (!empty($successMessage)) {
        echo "
        <div class='row mb-3'>
          <div class='offset-sm-3 col-sm-3 d-grid'>
            <div class='alert alert-success alert-dismissible fade show' role='alert'>
              <strong>$successMessage</strong>
            </div>
          </div>
        </div>
        ";
      }
      ?>

      <div class="row mb-3">
        <div class="offset-sm-3 col-sm-3 d-grid">
          <button type="submit" class="btn btn-primary">Submit</button>
        </div>
        <div class="col-sm-3 d-grid">
          <a class="btn btn-outline-primary" href="index_2.php" role="button">Cancel</a>
        </div>
      </div>

    </form>
  </div>
</body>
</html>