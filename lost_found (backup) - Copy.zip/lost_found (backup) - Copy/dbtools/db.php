<?php
function conn(){
  $server = "localhost";
  $user = "root";
  $pass = "";
  $database = "lost_and_found";

  $conn = new mysqli($server, $user, $pass, $database);
  if($conn->connect_error){
    die("Error failed to connect to MySQL: " . $conn->connect_error);
  }
  return $conn;
}
?>